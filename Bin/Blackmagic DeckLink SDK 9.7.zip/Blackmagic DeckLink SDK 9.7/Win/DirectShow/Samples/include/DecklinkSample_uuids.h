//------------------------------------------------------------------------------
// DecklinkSample_uuids.h
//
//------------------------------------------------------------------------------


// Decklink sample interfaces
DEFINE_GUID(IID_IDecklinkPushSource,				0xbc13bb43, 0xb681, 0x451b, 0x82, 0xc8, 0x8b, 0x66, 0xa9, 0xff, 0x38, 0x48);
DEFINE_GUID(IID_IDecklinkPushSource2,				0x1c109963, 0x8da9, 0x4eef, 0x9f, 0x2e, 0xd9, 0x35, 0x55, 0x91, 0x03, 0xce);
