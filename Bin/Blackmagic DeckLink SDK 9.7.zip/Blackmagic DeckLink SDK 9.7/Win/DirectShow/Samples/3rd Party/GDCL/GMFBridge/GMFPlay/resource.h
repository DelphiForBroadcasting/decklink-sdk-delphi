//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GMFPlay.rc
//
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDD_LIMITS                      201
#define IDC_LIST1                       1000
#define IDC_ADD                         1001
#define IDC_PLAY                        1002
#define IDC_STOP                        1003
#define IDC_LIMITS                      1004
#define IDC_PAUSE                       1005
#define IDC_LOOP                        1006
#define IDC_SLIDER1                     1007
#define IDC_DURATIONTEXT                1009
#define IDC_START                       1010
#define IDC_EDIT2                       1011
#define IDC_PLAYNEXT                    1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
