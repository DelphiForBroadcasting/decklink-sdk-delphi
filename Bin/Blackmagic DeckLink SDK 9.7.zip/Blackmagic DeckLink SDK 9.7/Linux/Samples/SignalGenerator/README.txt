If you have Qt installed in a non-standard location type 'qmake -makefile' to regenerate the Makefile to match your ennviroment
